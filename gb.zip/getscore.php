<?php

	include_once "conn.php";
	
	//$query = "SELECT email, score, playing_time FROM User WHERE ID_ROLE=2 ORDER by score DESC, playing_time ASC LIMIT 20";
	$query = "select email, sum(score) as score from scores
				group by email
				order by score desc
				limit 20;";
	$result = mysql_query($query) or die('Query failed: ' . mysql_error());
	
	$result_length = mysql_num_rows($result);
 
	for($i = 0; $i < $result_length; $i++)
	{
		 $row = mysql_fetch_array($result);
		 echo $row['email'] . "\t" . $row['score'] . "\n";
	}
	
?>