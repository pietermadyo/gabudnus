<?php
include('conn.php');

	if (isset($_POST['save']))
	{
		$email =$_POST["email"];
		$password = $_POST["password"];
		//$score = 0;
		$idrole = 1;
		
		 $query = "INSERT INTO user(EMAIL,PASSWORD,ID_ROLE,created) values('$email','$password',$idrole,NOW())";
		//$query = "INSERT INTO scores(email,score,created) values('$email',$score,NOW())";
		
		
		$result = mysql_query($query) or die('Query failed: ' . mysql_error());
		if($result){
			echo "data berhasil terkirim";
			$_SESSION['message'] = "Data berhasil ditambahkan!"; 
			header('location: tampiluser.php');
		}
		else
		{
			header('location: inputuser.php');
			echo "data gagal terkirim";
		}
	}
	
	//$results = mysqli_query($conn, "SELECT * FROM user");
?>