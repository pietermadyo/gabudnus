<?php

	include_once "conn.php";
	
	class score{}
	
	$id_pertanyaan =$_POST["id_pertanyaan"];
	
	$query = "INSERT INTO `toppertanyaan`(`id_pertanyaan`) VALUES ($id_pertanyaan)";
	$result = mysql_query($query) or die('Query failed: ' . mysql_error());
	if($result){
		echo "data berhasil terkirim";
	}
	else
	{
		echo "data gagal terkirim";
	}
?>