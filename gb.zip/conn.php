<?php

	// deklarasi variabel koneksi ke database
	$nama_database = "gabudnusdb";
	$username_mysql = "root";
	$password_mysql = "";
	$nama_server = "localhost";
	//membuat koneksi	
	$conn = mysqli_connect($nama_server,$username_mysql,$password_mysql,$nama_database);
	
	$db = mysql_connect($nama_server, $username_mysql, $password_mysql) or die('Failed to connect: ' . mysql_error());
        mysql_select_db($nama_database) or die('Failed to access database');
?>